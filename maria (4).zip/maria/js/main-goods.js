let swiper18;

addHandlerSlider(320,767,swiper18,'.s23 .tbs__wrapper--active','','','.s23 .s23-pagination','bullets','horizontal','false',1,1.5,3,2,20,20,20);
// addHandlerSlider(768,1366,swiper18,'.s23 .s23 .tbs__wrapper','','','','bullets','horizontal','false',1.5,1.5,3,2,20,20,20);


