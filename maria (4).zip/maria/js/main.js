let swiper1;
let swiper2;
let swiper3;
let swiper4;
let swiper5;
let swiper6;
let swiper7;

let swiper10;
let swiper11;
let swiper12;
let swiper13;
let swiper14;
let swiper15;
let swiper16,swiper18,swiper20;

const swiper=new Swiper('.s2-slider', {
    observer:true,
    observeParents:true,
    spaceBetween:40,
   centeredSlides:false,
    navigation: {
      prevEl: '.s2-slider .s2-prev',
    nextEl: '.s2-slider .s2-next',
    
  },
    breakpoints:{
      320:{
        slidesPerView: 2,
        spaceBetween:15
      },
      768:{
        slidesPerView: 1.5,
        spaceBetween:20
      },
      1300:{
        slidesPerView: 3,
        spaceBetween:40
      }
    },
    loop:false,
  });
console.log(swiper)
  

  const itemAsk=document.querySelectorAll('.item-ask');
  const buttons=document.querySelectorAll('.item-ask__btn');
  const burgerBtn=document.querySelectorAll('.nav-burger');
  const menuBlock=document.querySelectorAll('.menu-block');
  const cross=document.querySelectorAll('.cross');
  const s1=document.querySelector('.s1');
  const s11=document.querySelector('.s11');
  const s12=document.querySelector('.s12');

  const header=document.querySelector('.header');

  function closeAll(list,nameClass){
    list.forEach(elem=>{
      elem.classList.remove(nameClass)
    });
  }
  function addAll(list,nameClass){
    list.forEach(elem=>{
      elem.classList.add(nameClass)
    });
  }

  itemAsk.forEach((item,i)=>{

    item.addEventListener('click',function(){
      closeAll(itemAsk,'item-ask__active')
       console.log(this)
        this.classList.toggle('item-ask__active');
      })
  })
 
  document.addEventListener('click',(e)=>{
    const burgerBtn=document.querySelectorAll('.nav-burger');
  const menuBlock=document.querySelectorAll('.menu-block');
  const cross=document.querySelectorAll('.cross');
    console.log(e.target,burgerBtn)
    if(e.target===document.querySelector('.nav-burger')){

    addAll(burgerBtn,'nav-burger__active')
    console.log(burgerBtn)
  
      addAll(menuBlock,'menu-block__active')
     
      addAll(cross,'cross-active')
     
     
      document.querySelectorAll('.cover').forEach(el=>{
        el.classList.add('cover-active');
      })
    }
      
  
  
    if(e.target===document.querySelector('.cross')  || !e.target.closest('.menu-block') && e.target!==document.querySelector('.nav-burger')){
      closeAll(cross,'cross-active')
   
    closeAll(menuBlock,'menu-block__active')
   
    closeAll(burgerBtn,'nav-burger__active')
    
    document.querySelectorAll('.cover').forEach(el=>{
      el.classList.remove('cover-active');
    })
  }
});


  //Tabs
document.querySelectorAll('.tabs__wrapper').forEach(elem=>{

  const tabs=elem.querySelector('.tabs')
  const tabsContent=elem.querySelectorAll('.tbs__wrapper')
  tabs.querySelectorAll('li')[0].classList.add('tab-active');
  addToTabs(tabs,'tab-active',tabsContent,'tbs__wrapper--active')
 

tabs.addEventListener('click',function(e){
  e.preventDefault()
  let target=e.target;
  if(target.closest('a')){
    e.preventDefault()
    deleteTabClass(tabs,'tab-active');
    target.closest('li')?.classList.add('tab-active');
    addToTabs(tabs,'tab-active',tabsContent,'tbs__wrapper--active');

    addHandlerSlider(320,767,swiper7,'.s9 .tabs-inner','','','.s9 .s9-pagination','bullets','horizontal','false',1,1.3,2,2,40,40,40);
    addHandlerSlider(768,1280,swiper7,'.s9 .tabs-inner','.s9 .s2-prev','.s9 .s2-next','','','horizontal','false',1,1.3,2,2,40,40,40);
   


const wrapHandler=function(){


  addHandlerSlider(320,767,swiper16,'.s020 .tbs__wrapper--active .tabs__slider','','','.s020 .tbs__wrapper--active .s020-pagination','bullets','horizontal','false',1,1,2,1,40,40,40);
  addHandlerSlider(768,1920,swiper16,'.s020 .tbs__wrapper--active .tabs__slider','.s020 .s2-prev','.s020 .s2-next','','','horizontal','false',1,1,2,1,40,40,40);



  addHandlerSlider(320,767,swiper7,'.s9 .tabs-inner','','','.s9 .s9-pagination','bullets','horizontal','false',1,1.3,3,2,40,40,40);
addHandlerSlider(768,1200,swiper7,'.s9 .tabs-inner','.s9 .s2-prev','.s9 .s2-next','','','horizontal','false',1,1.3,3,2,40,40,40);

addHandlerSlider(320,767,swiper18,'.s23 .tbs__wrapper--active','','','.s23 .s23-pagination','bullets','horizontal','false',1,1.5,3,2,20,20,20);
  
};
wrapHandler()
  
  }
})

function addToTabs(selector,className,selector1,className1){
  console.log(selector)
  const idx=Array.from(selector.querySelectorAll('li')).findIndex(el=>{
    
    return el.classList.contains(className)
  });
   console.log(idx)
   selector1.forEach(el=>el.classList.remove(className1))
   selector1[idx].classList.add(className1)

}

function deleteTabClass(selector,className){
  selector.querySelectorAll('li').forEach(el=>el.classList.remove(className));
 
}

});
 


// const wrapSlides=(min,max,containerClass,itemsInDiv,itemsOutDiv,num)=>{
//   let target;
//   if(window.innerWidth>=min && window.innerWidth<=max){
//     target=document.querySelector(containerClass);
//     let slides=Array.from(document.querySelectorAll(itemsInDiv));
//     console.log(slides)
//     let count=Math.ceil(slides.length/num);
//     console.log(count)
   
//     for(let i=0;i<count; i++){
//       if(slides.length===0) return;
//         let wrapper=document.createElement('div');
//         wrapper?.classList.add('swiper-slide', 'item');
//         let newArr=slides.splice(0,num);
//         console.log(slides)
//         wrapper.append(...newArr);
//         target.append(wrapper);
//       }
     
    
//   }else{
//     target=document.querySelector(containerClass);
//     let slidesItems=Array.from(document.querySelectorAll(itemsOutDiv));
//     if(slidesItems.length>0) target.append(...slidesItems);
//     document.querySelector(containerClass)?.querySelectorAll('.item').forEach(el=>el.remove())
//   }
 
// };


// wrapSlides(320,1200,'.s8 .block__wrapper',
//             '.s8 .block__wrapper>.block__item',
//             '.s8 .block__wrapper .block__item',
//             2
// )
// wrapSlides(320,1200,'.s9 .tbs__wrapper--active',
//             '.s9 .tbs__wrapper--active>.tabs-inner__item',
//             '.s9 .tbs__wrapper--active .tabs-inner__item',
//             2
// )
// wrapSlides(320,767,'.s11 .b1__list',
//             '.s11 .b1__list>.b1__list-item',
//             '.s11 .b1__list .b1__list-item',
//             2
// )



function moveElement(){
  if(window.innerWidth<768){

    let promo=document.querySelector(".s1 .t1__promo");
    if(promo) document.querySelector('.s1 .block').append(promo);
    let buttons=document.querySelector(".s1 .t1__links");
    if(buttons) document.querySelector('.s1 .t1').append(buttons);

    document.querySelectorAll('.s9 .tabs-inner__item').forEach((el,i)=>{
      let image=el.querySelector('.img-container');
      el.querySelector('.text-block').insertBefore(image,el.querySelector('.text-block p'));
    });
  }
  if(window.innerWidth>=768 && window.innerWidth<=1200){
    let promo=document.querySelector(".s1 .t1__promo");
    if(promo) document.querySelector('.s1 .block').append(promo);

    let buttons=document.querySelector(".s1 .t1__links");
    if(buttons) document.querySelector('.s1 .block').append(buttons);

    
    

    document.querySelectorAll('.s9 .tabs-inner__item').forEach((el,i)=>{
      let image=el.querySelector('.text-block .img-container');
     if(image) el.prepend(image);
    });
  }
  if(window.innerWidth>1200){
    let buttons=document.querySelector(".s1 .t1__links");
    if(buttons) document.querySelector('.s1 .t1')?.append(buttons);

    let promo=document.querySelector(".s1 .t1__promo");
    if(promo) document.querySelector('.s1 .t1')?.append(promo);

    document.querySelectorAll('.s9 .tabs-inner__item').forEach((el,i)=>{
      let image=el.querySelector('.text-block .img-container');
     if(image) el.prepend(image);
    });
  }
}


function fromBoxMove(){
  if(window.innerWidth<768){
   
   


    const elems=Array.from(document.querySelectorAll('.s3 .ll2__item'));
    const where=document.querySelector('.s3 .put-here-slider');
    if(elems) where?.append(...elems);

//     wrapSlides(768,1200,'.s3 .put-here-slider',
//     '.s3 .put-here-slider>.item-slide',
//     '.s3 .put-here-slider .item-slide',
//     3
// )

    // where?.querySelectorAll('.item-slide').forEach(el=>el.classList.add('swiper-slide'));
  }
  else  if(window.innerWidth>=768 && window.innerWidth<=1200 ){

    const elems=Array.from(document.querySelectorAll('.s3 .ll2__item'));
    const where=document.querySelector('.s3 .put-here-slider');
    if(elems) where?.append(...elems);
    
    // document.querySelector('.s3 .put-here-slider')?.querySelectorAll('.item-slide').forEach(el=>el.classList.remove('swiper-slide'));
    // const backElem=Array.from(document.querySelectorAll('.s3 .ll2__item'));
    // document.querySelector('.s3 .ll2').append(...backElem);
//     wrapSlides(320,767,'.s3 .put-here-slider',
//     '.s3 .put-here-slider > .item-slide',
//     '.s3 .put-here-slider .item-slide',
//     3
// )

//     wrapSlides(768,1200,'.s3 .put-here-slider',
//     '.s3 .put-here-slider > .item-slide',
//     '.s3 .put-here-slider .item-slide',
//     3
// )

      
      
    
  }
  else{
    const backElem=Array.from(document.querySelectorAll('.s3 .ll2__item'));
    if(backElem) document.querySelector('.s3 .ll2')?.append(...backElem);



  }
}


function putClassSlider(){
  if(window.innerWidth<768){
    document.querySelector('.s3 .put-here-slider')?.classList.add('swiper-wrapper');
    document.querySelector('.s4 .block__inner')?.classList.add('swiper-wrapper');
    // document.querySelector('.s4 .s4-pagination')?.classList.add('show');
    document.querySelector('.s8 .swiper-preview .buttons')?.classList.add('show-flex');
    document.querySelector('.s12 .s12-middle-slider .ll1')?.classList.add('swiper-wrapper')
    // document.querySelector('.s9 .tbs__wrapper--active')?.classList.add('swiper-wrapper');
  } else if(window.innerWidth>1200){
    document.querySelector('.s12 .s12-middle-slider .ll1')?.classList.add('swiper-wrapper')
    document.querySelector('.s3 .put-here-slider')?.classList.remove('swiper-wrapper');
    document.querySelector('.s4 .block__inner')?.classList.remove('swiper-wrapper');
  }else{
    document.querySelector('.s12 .s12-middle-slider .ll1')?.classList.remove('swiper-wrapper')
    document.querySelector('.s3 .put-here-slider')?.classList.add('swiper-wrapper');
    document.querySelector('.s4 .block__inner')?.classList.add('swiper-wrapper');
    // document.querySelector('.s4 .s4-pagination')?.classList.remove('show');
    document.querySelector('.s8 .swiper-preview .buttons')?.classList.remove('show-flex');
    // document.querySelector('.s9 .tbs__wrapper--active')?.classList.add('swiper-wrapper');
  }
 
}
moveElement()
putClassSlider()
fromBoxMove()
window.addEventListener('resize',moveElement);
window.addEventListener('resize',fromBoxMove)
window.addEventListener('resize',putClassSlider)
// window.addEventListener('resize',function(){
//   wrapSlides(320,1200,'.s8 .block__wrapper',
//   '.s8 .block__wrapper>.block__item',
//   '.s8 .block__wrapper .block__item',
//   2
// )
// })
// window.addEventListener('resize',function(){
//   wrapSlides(320,1200,'.s9 .tbs__wrapper--active',
//   '.s9 .tbs__wrapper--active>.tabs-inner__item',
//   '.s9 .tbs__wrapper--active .tabs-inner__item',
//   2
// )
// })

// window.addEventListener('resize',function(){
// wrapSlides(320,767,'.s11 .b1__list',
//             '.s11 .b1__list>.b1__list-item',
//             '.s11 .b1__list .b1__list-item',
//             2
// )
// });

// wrapSlides(320,767,'.s12 .ll1',
// '.s12 .ll1>.ll1__item',
// '.s12 .ll1 .ll1__item',
// 3
// )
// window.addEventListener('resize',function(){
//   wrapSlides(320,767,'.s12 .ll1',
//               '.s12 .ll1>.ll1__item',
//               '.s12 .ll1 .ll1__item',
//               3
//   )
//   });


const addHandlerSlider=(min,max,slider,sliderClass,...sliderParams)=>{
  
  
  let target=document.querySelector(sliderClass);
  
  if(!target) return;
  if(window.innerWidth>=min && window.innerWidth<=max){
    if(slider) {
      return;
    }
    else{
      slider = new Swiper(sliderClass, {
      
      observer:true,
      observeParents:true,
      navigation: {
        prevEl: sliderParams[0],
      nextEl: sliderParams[1],
      
    },
    grid:{
      fill:'row',
      rows:sliderParams[9]
    },
    pagination:{
      el:sliderParams[2],
      type:sliderParams[3],
      clickable:true
    },
    centeredSlides:false,
    initialSlide:0,
    direction:sliderParams[4],
    breakpoints:{
      320:{
        slidesPerView:sliderParams[6],
        spaceBetween:sliderParams[10],
        
      },
      768:{
        slidesPerView:sliderParams[7],
        spaceBetween:sliderParams[11],
      
      },
      1280:{
        slidesPerView:sliderParams[8],
        spaceBetween:sliderParams[12],
      
      }
    }
    

    });
  }
}else{
  if(slider){
    slider.destroy();
    slider=undefined;
  }
}


  window.addEventListener('resize',function(){
   
    let target=document.querySelector(sliderClass);
    if(!target) return;
    if(window.innerWidth>=min && window.innerWidth<=max){
      
      if(slider) {
       
        return;
      }
        else{
       
          slider = new Swiper(sliderClass, {
            observer:true,
            observeParents:true,
            navigation: {
              prevEl: sliderParams[0],
            nextEl: sliderParams[1],
            
          },
          grid:{
            fill:'row',
            rows:sliderParams[9]
          },
          pagination:{
            el:sliderParams[2],
            type:sliderParams[3],
            clickable:true
          },
          centeredSlides:false,
          initialSlide:0,
          direction:sliderParams[4],

          breakpoints:{
            320:{
              slidesPerView:sliderParams[6],
              spaceBetween:sliderParams[10],
             
            },
            768:{
              slidesPerView:sliderParams[7],
              spaceBetween:sliderParams[11],
            },
            1280:{
              slidesPerView:sliderParams[8],
              spaceBetween:sliderParams[12],
            }
          }
    
          })
        }
       
    }else {
     
    if(slider ){
      console.log(slider)
      if(Array.isArray(slider)) {
        console.log(slider)
        slider.forEach(el=>{
          el.destroy();
          el=null;
        });
        
      }
       else{
        slider.destroy()
        slider=null;
       }
       slider=null;
        console.log(slider)
      }
    }
    
  });
}

const allHandlers=function(){
  addHandlerSlider(320,767,swiper2,'.s3 .swiper-way','.s3 .s2-prev','.s3 .s2-next','','','horizontal','true',1,1,3,0,0,0,0);
  addHandlerSlider(768,1200,swiper2,'.s3 .swiper-way','.s3 .btn-big .s2-prev','.s3 .btn-big .s2-next','','','horizontal','true',1,1,3,3,0,0,0);
  addHandlerSlider(320,767,swiper4,'.swiper4-prof','','','.s4 .s4-pagination',"bullets",'horizontal','true',1,2,3,2,0,0,0);
  addHandlerSlider(768,1200,swiper4,'.swiper4-prof','','','',"",'horizontal','true',1,2,2,2,20,20,20);
  
  
    addHandlerSlider(320,767,swiper1,'.s6 .tabs__slider','','','.s6 .s6-pagination',"bullets",'horizontal','false',1,1,2,1,0,0,0);
    addHandlerSlider(768,1920,swiper1,'.s6 .tabs__slider','.s6 .s2-prev','.s6 .s2-next','',"",'horizontal','false',1,1.2,2,1,40,40,40);
    
    addHandlerSlider(320,767,swiper10,'.s018 .tabs__slider','','','.s018 .s6-pagination',"bullets",'horizontal','false',1,1,3,0,0,0,0);
    addHandlerSlider(768,1920,swiper10,'.s018 .tabs__slider','.s018 .s2-prev','.s018 .s2-next','',"",'horizontal','false',1,1.2,2,0,0,0,0);
  
  
  addHandlerSlider(320,767,swiper6,'.s8 .swiper-preview','.s8 .s2-prev','.s8 .s2-next','',"",'horizontal','false',1,1,3,2,20,20,20);
  addHandlerSlider(768,1280,swiper6,'.s8 .swiper-preview','.s8 .s2-prev','.s8 .s2-next','',"",'horizontal','false',1,2,3,2,40,40,40);
  
  addHandlerSlider(320,767,swiper7,'.s9 .tbs__wrapper--active .tabs-inner','','','.s9 .s9-pagination','bullets','horizontal','false',1,1.3,3,2,20,20,20);
  addHandlerSlider(768,1280,swiper7,'.s9 .tbs__wrapper--active .tabs-inner','.s9 .s2-prev','.s9 .s2-next','','','horizontal','false',1,1.3,2,2,40,40,40);
  
  addHandlerSlider(320,767,swiper11,'.s11 .s11-slider','','','','','horizontal','false',1.5,1,3,2,20,20,20);
  addHandlerSlider(320,767,swiper12,'.s12 .s12-slider-top','','','','','horizontal','true',1.2,3,4,0,20,20,20);
  addHandlerSlider(768,1199,swiper12,'.s12 .s12-slider-top','.s12-slider-top .s2-prev','.s12-slider-top .s2-next','','','horizontal','false',1.5,3,4,1,20,20,20);
  addHandlerSlider(1200,1366,swiper12,'.s12 .s12-slider-top','','','','','horizontal','false',1.5,3,4,0,0,0,0);
  
  addHandlerSlider(320,767,swiper13,'.s12 .s12-middle-slider','','','.s12 .s12-pagination','bullets','horizontal','false',1,1,3,3,20,20,20);
  
  addHandlerSlider(320,767,swiper14,'.s15 .s15-swiper','.s15 .s2-prev','.s15 .s2-next','','','horizontal','false',2,1,3,0,0,0,0);
}


  allHandlers()





//Modal window

const btnModal=document.querySelector('.s18 .t1 .t1__info .btn-320');
const modal=document.querySelector('.s18 .l1');

document.addEventListener('click',function(e){
  if(e.target===btnModal){
    modal?.classList.add('s18-modal-open')
  }
  else if(!e.target.closest('.l1') && e.target!==btnModal) 
  modal?.classList.remove('s18-modal-open')
});
