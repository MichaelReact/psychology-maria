let swiper19;

addHandlerSlider(320,767,swiper19,'.s22 .s22-slider','','','.s22 .s22-pagination','bullets','horizontal','false',1,2,3,2,20,20,20);
addHandlerSlider(320,1200,swiper19,'.s22 .s22-slider','','','','','horizontal','false',1,2,3,1,20,20,20);