let swiper17;

const btnModal1=document.querySelector('.s21 .btn-wrapper .btn:first-child');
const modal1=document.querySelector('.s21 .table-container');

document.addEventListener('click',function(e){
    
  if(e.target===btnModal1){
    e.preventDefault()
    modal1?.classList.add('show-table')
  }
  else if(!e.target.closest('.form-container') && !e.target.closest('.table-container')) 
  modal1?.classList.remove('show-table')
});

addHandlerSlider(320,767,swiper15,'.s19 .s19-slider','','','.s19 .s19-pagination','bullets','horizontal','false',1.5,2,3,0,20,20,20);
addHandlerSlider(768,1280,swiper15,'.s19 .s19-slider','','','','bullets','horizontal','false',1.5,1.5,3,0,20,20,20);

addHandlerSlider(320,767,swiper16,'.s020 .tbs__wrapper--active .tabs__slider','','','.s020 .tbs__wrapper--active .s020-pagination','bullets','horizontal','false',1,1,2,1,40,40,40);
addHandlerSlider(768,1920,swiper16,'.s020 .tbs__wrapper--active .tabs__slider','.s020 .s2-prev','.s020 .s2-next','','','horizontal','false',1,1,2,1,40,40,40);




addHandlerSlider(320,767,swiper17,'.s20-slider','.s20 .s2-prev','.s20 .s2-next','',"",'horizontal','false',1,1.2,2,2,20);